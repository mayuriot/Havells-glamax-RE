/**
 * @file BP5758D.cpp
 * @brief Implementation of BP5758D LED Driver Library
 * @author Mayur sen (YouTube: MayurioT, Mail: mayuriot1@gmail.com)
 */

#include "BP5758D.h"

// Command register addresses
#define BP5758D_CMD_ENABLE 0xB0
#define BP5758D_CMD_SLEEP  0x80

static const uint8_t currentCmd[5]    = { 0xB1, 0xB2, 0xB3, 0xB4, 0xB5 };
static const uint8_t brightnessCmd[5] = { 0xB6, 0xB8, 0xBA, 0xBC, 0xBE };

BP5758D::BP5758D(uint8_t sdaPin, uint8_t sclPin)
  : _sdaPin(sdaPin), _sclPin(sclPin), _isSleeping(false) {
  _currents[0] = 15; // Red (OUT1)
  _currents[1] = 15; // Green (OUT2)
  _currents[2] = 15; // Blue (OUT3)
  _currents[3] = 40; // Warm White (OUT4)
  _currents[4] = 40; // Cool White (OUT5)

  for (int i = 0; i < BP5758D_CHANNELS; i++) {
    _grayscales[i] = 0;
  }
}

inline void BP5758D::delayClock() {
  delayMicroseconds(3);
}

inline void BP5758D::sdaLow() {
  pinMode(_sdaPin, OUTPUT);
  digitalWrite(_sdaPin, LOW);
}

inline void BP5758D::sdaRelease() {
  pinMode(_sdaPin, INPUT);
}

inline void BP5758D::sclLow() {
  digitalWrite(_sclPin, LOW);
}

inline void BP5758D::sclRelease() {
  digitalWrite(_sclPin, HIGH);
}

void BP5758D::startCondition() {
  sdaRelease();
  sclRelease();
  delayClock();

  sdaLow();
  delayClock();

  sclLow();
}

void BP5758D::stopCondition() {
  sdaLow();
  delayClock();

  sclRelease();
  delayClock();

  sdaRelease();
  delayClock();
}

bool BP5758D::writeByte(uint8_t data) {
  for (uint8_t i = 0; i < 8; i++) {
    sclLow();
    if (data & 0x80) {
      sdaRelease();
    } else {
      sdaLow();
    }
    delayClock();
    sclRelease();
    delayClock();
    data <<= 1;
  }

  // 9th bit: Sample ACK from BP5758D
  sclLow();
  sdaRelease();
  delayClock();

  sclRelease();
  delayClock();

  bool ack = (digitalRead(_sdaPin) == LOW);

  sclLow();
  delayClock();

  return ack;
}

bool BP5758D::writeCommand(uint8_t command, const uint8_t *data, uint8_t length) {
  bool ack = true;
  startCondition();

  if (!writeByte(command)) {
    ack = false;
  }

  for (uint8_t i = 0; i < length; i++) {
    if (!writeByte(data[i])) {
      ack = false;
    }
  }

  stopCondition();
  return ack;
}

bool BP5758D::begin() {
  pinMode(_sclPin, OUTPUT);
  sclRelease();
  sdaRelease();
  delay(100);

  bool found = detect();
  enableOutputs(0x1F); // Enable all 5 channels

  // Apply default currents
  for (uint8_t i = 0; i < BP5758D_CHANNELS; i++) {
    setCurrent(i, _currents[i]);
    setBrightness(i, 0);
  }

  _isSleeping = false;
  return found;
}

bool BP5758D::detect() {
  uint8_t data = 0x00;
  return writeCommand(BP5758D_CMD_ENABLE, &data, 1);
}

void BP5758D::setCurrent(uint8_t channel, uint8_t mA) {
  if (channel >= BP5758D_CHANNELS || mA > 90 || mA == 0) return;
  _currents[channel] = mA;

  // BP5758D formula: <= 63 mA is direct; > 63 mA is mA + 34
  uint8_t val = (mA <= 63) ? mA : (uint8_t)(mA + 34);
  writeCommand(currentCmd[channel], &val, 1);
}

void BP5758D::setCurrents(uint8_t ch0, uint8_t ch1, uint8_t ch2, uint8_t ch3, uint8_t ch4) {
  setCurrent(0, ch0);
  setCurrent(1, ch1);
  setCurrent(2, ch2);
  setCurrent(3, ch3);
  setCurrent(4, ch4);
}

void BP5758D::setBrightness(uint8_t channel, uint16_t brightness) {
  if (channel >= BP5758D_CHANNELS) return;
  brightness = constrain(brightness, 0, 1023);
  _grayscales[channel] = brightness;

  if (_isSleeping && brightness > 0) {
    wakeup();
  }

  // BP5758D 10-bit brightness: Lower 5 bits first, then upper 5 bits
  uint8_t data[2];
  data[0] = brightness & 0x1F;
  data[1] = (brightness >> 5) & 0x1F;

  writeCommand(brightnessCmd[channel], data, 2);
}

void BP5758D::setChannels(uint16_t out1, uint16_t out2, uint16_t out3, uint16_t out4, uint16_t out5) {
  setBrightness(0, out1);
  setBrightness(1, out2);
  setBrightness(2, out3);
  setBrightness(3, out4);
  setBrightness(4, out5);
}

void BP5758D::setRGB(uint8_t r, uint8_t g, uint8_t b) {
  setBrightness(0, (uint16_t)r * 1023 / 255);
  setBrightness(1, (uint16_t)g * 1023 / 255);
  setBrightness(2, (uint16_t)b * 1023 / 255);
}

void BP5758D::setWhite(uint16_t warm, uint16_t cool) {
  setBrightness(3, warm);
  setBrightness(4, cool);
}

void BP5758D::setAll(uint16_t brightness) {
  for (uint8_t i = 0; i < BP5758D_CHANNELS; i++) {
    setBrightness(i, brightness);
  }
}

void BP5758D::enableOutputs(uint8_t mask) {
  mask &= 0x1F;
  writeCommand(BP5758D_CMD_ENABLE, &mask, 1);
}

void BP5758D::sleep() {
  enableOutputs(0x00);
  uint8_t dummy = 0;
  writeCommand(BP5758D_CMD_SLEEP, &dummy, 0);
  _isSleeping = true;
}

void BP5758D::wakeup() {
  enableOutputs(0x1F);
  _isSleeping = false;
}

uint8_t BP5758D::getCurrent(uint8_t channel) const {
  return (channel < BP5758D_CHANNELS) ? _currents[channel] : 0;
}

uint16_t BP5758D::getGrayscale(uint8_t channel) const {
  return (channel < BP5758D_CHANNELS) ? _grayscales[channel] : 0;
}

bool BP5758D::isSleeping() const {
  return _isSleeping;
}

