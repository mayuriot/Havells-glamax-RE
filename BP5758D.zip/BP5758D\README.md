# BP5758D Arduino Library

A fast, lightweight, and hardware-verified Arduino driver library for the **Bright Power Semiconductor BP5758D** 5-channel linear constant-current LED driver IC.

**Reverse engineered and developed by Mayur sen**  
* **YouTube**: [MayurioT](https://youtube.com/@MayurioT)  
* **Email**: [mayuriot1@gmail.com](mailto:mayuriot1@gmail.com)  

---

## Features

- **10-Bit Grayscale PWM (0 - 1023)**: Smooth dimming with 1024 distinct brightness steps per channel.
- **Independent Current Limits (1 - 90 mA)**: Configure current limits for each channel to protect delicate LEDs and prevent overheating.
- **Universal Architecture Support**: Compatible with ESP8266, ESP32, Arduino AVR (Uno/Nano/Mega), STM32, and RP2040.
- **Convenience Helpers**: Built-in functions for RGB color mixing, Tunable White (CCT) control, and low-power sleep modes.
- **Robust Open-Drain Bit-Banging**: Rock-solid communication timing matched directly to the BP5758D silicon specification.

---

## Hardware Pinout & Wiring

### Typical Connection (ESP8266 NodeMCU)

| BP5758D Pin | Pin Name | Description | Microcontroller Connection |
| :---: | :---: | :--- | :--- |
| **1** | `OUT1` | Red LED Current Sink | LED Cathode |
| **2** | `HV` | High Voltage DC Bus (>9.8V) | Rectified AC mains power |
| **3** | `SDA` | Serial Data line | **`D1` (GPIO5)** (w/ pull-up) |
| **4** | `SCL` | Serial Clock line | **`D2` (GPIO4)** (w/ pull-up) |
| **5** | `OUT5` | Cool White LED Current Sink | LED Cathode |
| **6** | `OUT4` | Warm White LED Current Sink | LED Cathode |
| **7** | `OUT3` | Blue LED Current Sink | LED Cathode |
| **8** | `OUT2` | Green LED Current Sink | LED Cathode |
| **EPAD** | `GND` | Ground / Thermal Pad | Common GND |

---

## Quick Start Example

```cpp
#include <BP5758D.h>

// ESP8266: SDA = D1, SCL = D2
BP5758D leds(D1, D2);

void setup() {
  Serial.begin(115200);

  // Initialize pins and detect IC
  if (!leds.begin()) {
    Serial.println("BP5758D not responding!");
  }

  // Set safe current limits (mA)
  // OUT1=15mA, OUT2=15mA, OUT3=15mA, OUT4=40mA, OUT5=40mA
  leds.setCurrents(15, 15, 15, 40, 40);

  // Set RGB Color (Red, Green, Blue from 0 to 255)
  leds.setRGB(255, 0, 128);

  // Set Tunable White (Warm, Cool from 0 to 1023)
  leds.setWhite(1023, 400);
}

void loop() {
  // Your code here
}
```

---

## API Reference

### Initialization & Setup
- `BP5758D(uint8_t sdaPin, uint8_t sclPin)`: Constructor specifying SDA and SCL pins.
- `bool begin()`: Configures pin modes, verifies communication, and enables all channels.
- `bool detect()`: Returns `true` if the BP5758D acknowledged communication on the bus.

### Current Limits (1 to 90 mA)
- `void setCurrent(uint8_t channel, uint8_t mA)`: Set current limit for single channel (`0..4`).
- `void setCurrents(uint8_t ch0, uint8_t ch1, uint8_t ch2, uint8_t ch3, uint8_t ch4)`: Set all 5 currents at once.

### Brightness & Color Control
- `void setBrightness(uint8_t channel, uint16_t brightness)`: Set 10-bit grayscale (`0..1023`) for single channel.
- `void setChannels(uint16_t out1, uint16_t out2, uint16_t out3, uint16_t out4, uint16_t out5)`: Set all 5 channels.
- `void setRGB(uint8_t r, uint8_t g, uint8_t b)`: Sets OUT1 (Red), OUT2 (Green), and OUT3 (Blue) from 8-bit values (0–255).
- `void setWhite(uint16_t warm, uint16_t cool)`: Sets OUT4 (Warm White) and OUT5 (Cool White) from 10-bit values (0–1023).
- `void setAll(uint16_t brightness)`: Sets all 5 channels to the same brightness.

### Power & Low-Power Sleep
- `void enableOutputs(uint8_t mask)`: 5-bit mask to enable/disable specific channels.
- `void sleep()`: Puts the driver into ultralow-power standby mode.
- `void wakeup()`: Wakes up the driver.

---

## License

MIT License. Free for commercial and non-commercial open-source use.

