/**
 * @file BP5758D.h
 * @brief Arduino Library for Bright Power Semiconductor BP5758D 5-Channel LED Driver
 * @author Mayur sen (YouTube: MayurioT, Mail: mayuriot1@gmail.com)
 * 
 * Hardware Description:
 * - 5-Channel linear constant-current driver IC (ESOP-8 package)
 * - 10-bit grayscale PWM control (0 - 1023) per channel
 * - Independent current limit settings (1 - 90 mA) per channel
 * - Open-drain bit-banged I2C-like serial communication
 * 
 * Channel Mapping on standard RGBCW fixtures:
 *   CH 0 (OUT1, Pin 1) -> Red LED
 *   CH 1 (OUT2, Pin 8) -> Green LED
 *   CH 2 (OUT3, Pin 7) -> Blue LED
 *   CH 3 (OUT4, Pin 6) -> Warm White LED
 *   CH 4 (OUT5, Pin 5) -> Cool White LED
 */

#ifndef BP5758D_H
#define BP5758D_H

#include <Arduino.h>

#ifndef D1
  #define D1 5
#endif
#ifndef D2
  #define D2 4
#endif

#define BP5758D_CHANNELS 5

class BP5758D {
private:
  uint8_t _sdaPin;
  uint8_t _sclPin;
  uint8_t _currents[BP5758D_CHANNELS];     // mA (1 - 90 mA)
  uint16_t _grayscales[BP5758D_CHANNELS]; // 10-bit brightness (0 - 1023)
  bool _isSleeping;

  void delayClock();
  void sdaLow();
  void sdaRelease();
  void sclLow();
  void sclRelease();
  void startCondition();
  void stopCondition();
  bool writeByte(uint8_t data);
  bool writeCommand(uint8_t command, const uint8_t *data, uint8_t length);

public:
  /**
   * @brief Construct a new BP5758D object
   * @param sdaPin GPIO pin for SDA (default D1 / GPIO5 on ESP8266)
   * @param sclPin GPIO pin for SCL (default D2 / GPIO4 on ESP8266)
   */
  BP5758D(uint8_t sdaPin = D1, uint8_t sclPin = D2);

  /**
   * @brief Initialize pins and communication with BP5758D
   * @return true if BP5758D acknowledged communication, false otherwise
   */
  bool begin();

  /**
   * @brief Detect / Ping BP5758D on the serial bus
   * @return true if ACK received, false otherwise
   */
  bool detect();

  /**
   * @brief Set current limit in mA for a single channel
   * @param channel Channel index (0..4 for OUT1..OUT5)
   * @param mA Current limit in mA (1 to 90 mA)
   */
  void setCurrent(uint8_t channel, uint8_t mA);

  /**
   * @brief Set current limits for all 5 channels simultaneously
   */
  void setCurrents(uint8_t ch0, uint8_t ch1, uint8_t ch2, uint8_t ch3, uint8_t ch4);

  /**
   * @brief Set 10-bit grayscale brightness (0 - 1023) for single channel
   * @param channel Channel index (0..4 for OUT1..OUT5)
   * @param brightness Grayscale value from 0 (OFF) to 1023 (100% full)
   */
  void setBrightness(uint8_t channel, uint16_t brightness);

  /**
   * @brief Set brightness for all 5 channels simultaneously
   */
  void setChannels(uint16_t out1, uint16_t out2, uint16_t out3, uint16_t out4, uint16_t out5);

  /**
   * @brief Helper to set RGB channels (OUT1=Red, OUT2=Green, OUT3=Blue)
   * @param r Red value (0 - 255)
   * @param g Green value (0 - 255)
   * @param b Blue value (0 - 255)
   */
  void setRGB(uint8_t r, uint8_t g, uint8_t b);

  /**
   * @brief Helper to set White channels (OUT4=Warm, OUT5=Cool)
   * @param warm Warm White 10-bit brightness (0 - 1023)
   * @param cool Cool White 10-bit brightness (0 - 1023)
   */
  void setWhite(uint16_t warm, uint16_t cool);

  /**
   * @brief Set all 5 channels to the same brightness
   */
  void setAll(uint16_t brightness);

  /**
   * @brief Enable/Disable outputs with a 5-bit channel bitmask
   * @param mask Bitmask (bit 0=OUT1, bit 1=OUT2, bit 2=OUT3, bit 3=OUT4, bit 4=OUT5)
   */
  void enableOutputs(uint8_t mask);

  /**
   * @brief Put the BP5758D into low-power sleep mode
   */
  void sleep();

  /**
   * @brief Wake up the BP5758D from sleep mode
   */
  void wakeup();

  /**
   * @brief Get current limit setting of a channel
   */
  uint8_t getCurrent(uint8_t channel) const;

  /**
   * @brief Get current grayscale brightness setting of a channel
   */
  uint16_t getGrayscale(uint8_t channel) const;

  /**
   * @brief Check whether driver is in sleep mode
   */
  bool isSleeping() const;
};

#endif // BP5758D_H

