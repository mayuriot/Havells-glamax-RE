/**
 * @file 01_BasicChannelTest.ino
 * @brief Simple test cycling through all 5 channels of BP5758D
 * @author Mayur sen (YouTube: MayurioT, Mail: mayuriot1@gmail.com)
 */

#include <BP5758D.h>

// On ESP8266 NodeMCU: D1 = GPIO5 (SDA), D2 = GPIO4 (SCL)
// On ESP32: You can use any GPIO (e.g. 21 SDA, 22 SCL)
// On Arduino Uno/Nano: A4 (SDA), A5 (SCL)
BP5758D leds(D1, D2);

const char* channelNames[5] = {
  "OUT1 (Red)",
  "OUT2 (Green)",
  "OUT3 (Blue)",
  "OUT4 (Warm White)",
  "OUT5 (Cool White)"
};

void setup() {
  Serial.begin(115200);
  delay(100);

  Serial.println();
  Serial.println("==================================================");
  Serial.println("  BP5758D 5-Channel LED Driver - Basic Test");
  Serial.println("  Library by Mayur sen (MayurioT)");
  Serial.println("==================================================");

  // Initialize driver
  if (!leds.begin()) {
    Serial.println("[WARN] BP5758D not acknowledging. Check HV AC power.");
  } else {
    Serial.println("[OK] BP5758D detected and ready!");
  }

  // Configure safe current limits (mA):
  // RGB LEDs typically use 15-20mA; High power White LEDs use 30-50mA
  leds.setCurrent(0, 15); // OUT1 Red
  leds.setCurrent(1, 15); // OUT2 Green
  leds.setCurrent(2, 15); // OUT3 Blue
  leds.setCurrent(3, 40); // OUT4 Warm White
  leds.setCurrent(4, 40); // OUT5 Cool White
}

void loop() {
  // Test each channel sequentially
  for (int ch = 0; ch < 5; ch++) {
    Serial.print("Testing: ");
    Serial.println(channelNames[ch]);

    // Turn ON full brightness (1023)
    leds.setBrightness(ch, 1023);
    delay(1000);

    // Turn OFF
    leds.setBrightness(ch, 0);
    delay(300);
  }

  // Blink all together
  Serial.println("All channels ON");
  leds.setAll(512); // ~50%
  delay(1500);

  Serial.println("All channels OFF");
  leds.setAll(0);
  delay(1000);
}

