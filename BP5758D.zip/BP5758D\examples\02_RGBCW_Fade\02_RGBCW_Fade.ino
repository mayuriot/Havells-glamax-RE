/**
 * @file 02_RGBCW_Fade.ino
 * @brief Smooth 10-bit PWM breathing/fading demo across RGBCW channels
 * @author Mayur sen (YouTube: MayurioT, Mail: mayuriot1@gmail.com)
 */

#include <BP5758D.h>

BP5758D leds(D1, D2);

void setup() {
  Serial.begin(115200);
  leds.begin();

  // Set currents
  leds.setCurrents(15, 15, 15, 40, 40);
  Serial.println("BP5758D RGBCW Smooth Fade Demo");
}

void loop() {
  // Fade in Warm White + Red
  Serial.println("Fading Warm Red...");
  for (int b = 0; b <= 1023; b += 15) {
    leds.setBrightness(0, b / 2); // Red
    leds.setBrightness(3, b);     // Warm White
    delay(20);
  }

  // Fade out
  for (int b = 1023; b >= 0; b -= 15) {
    leds.setBrightness(0, b / 2);
    leds.setBrightness(3, b);
    delay(20);
  }

  // Fade in Cool White + Blue
  Serial.println("Fading Cool Blue...");
  for (int b = 0; b <= 1023; b += 15) {
    leds.setBrightness(2, b / 2); // Blue
    leds.setBrightness(4, b);     // Cool White
    delay(20);
  }

  // Fade out
  for (int b = 1023; b >= 0; b -= 15) {
    leds.setBrightness(2, b / 2);
    leds.setBrightness(4, b);
    delay(20);
  }
}

