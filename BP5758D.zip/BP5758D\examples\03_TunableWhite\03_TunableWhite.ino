/**
 * @file 03_TunableWhite.ino
 * @brief Tunable White CCT blending (2700K Warm White to 6500K Cool White)
 * @author Mayur sen (YouTube: MayurioT, Mail: mayuriot1@gmail.com)
 */

#include <BP5758D.h>

BP5758D leds(D1, D2);

// Function to blend Warm (OUT4) and Cool (OUT5) by Kelvin
void setCCT(uint16_t kelvin, uint16_t masterBrightness = 1023) {
  kelvin = constrain(kelvin, 2700, 6500);
  float ratio = (float)(kelvin - 2700) / (6500 - 2700);

  uint16_t cool = (uint16_t)(ratio * masterBrightness);
  uint16_t warm = (uint16_t)((1.0f - ratio) * masterBrightness);

  leds.setWhite(warm, cool);
}

void setup() {
  Serial.begin(115200);
  leds.begin();
  leds.setCurrent(3, 40); // OUT4 Warm White
  leds.setCurrent(4, 40); // OUT5 Cool White

  Serial.println("BP5758D Tunable White CCT Sweep");
}

void loop() {
  // Sweep from Warm (2700K) to Cool (6500K)
  Serial.println("Sweeping 2700K -> 6500K");
  for (uint16_t k = 2700; k <= 6500; k += 50) {
    setCCT(k, 1023);
    delay(40);
  }

  delay(1000);

  // Sweep from Cool (6500K) back to Warm (2700K)
  Serial.println("Sweeping 6500K -> 2700K");
  for (uint16_t k = 6500; k >= 2700; k -= 50) {
    setCCT(k, 1023);
    delay(40);
  }

  delay(1000);
}

